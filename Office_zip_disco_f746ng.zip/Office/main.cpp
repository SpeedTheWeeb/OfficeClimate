#include "mbed.h"
#include "LCD_DISCO_F746NG.h"
#include "Grove_LCD_RGB_Backlight.h"
#include "TS_DISCO_F746NG.h"

// Initialization of threads
Thread thread;
Thread Cthread;
Thread LCDThread;

// Initialization of pins
AnalogIn Temp(A3);
Grove_LCD_RGB_Backlight LED(PB_9, PB_8);
DigitalOut BlueLight(D8);

// Initialization of other objects
LCD_DISCO_F746NG lcd;
TS_DISCO_F746NG ts;

// Variables
float temperature, resistance;
unsigned int a, beta = 3975;
float CelFahr;
int change = 1;
char t[1024];

// Temperature calculator
void TempMath(int CF)
{
    a = Temp.read_u16();
    resistance= (float) 10000.0 * ((65536.0 / a) - 1.0);
        
    /* 
        Convert the resistance to temperature using Steinhart's Hart equation
        Will convert resistance to Celcius
    */
    temperature=(1/((log(resistance/10000.0)/beta) + (1.0/298.15)))-273.15;
    if(CF == 0)
    {
        // Formular for converting Celcius to Fahrenheit
        CelFahr = temperature*1.8+32;
    }
    else if(CF == 1)
    {
        CelFahr = temperature;
    }
    sprintf((char*)t, "    Temperature: %f    ", CelFahr);
        
    //lcd.DisplayStringAt(0, LINE(1), (uint8_t*)t, CENTER_MODE);
    
    // Turn on lights depending on temperature
    switch(CF)
    {
        case 0:
            if(CelFahr < 77)
            {
                LED.setRGB(0, 255, 0);
            }
            else if(CelFahr > 77 && CelFahr < 83)
            {
                LED.setRGB(255, 255, 0);
            }
            else if(CelFahr > 83)
            {
                LED.setRGB(255, 0, 0);
            }
            break;
        case 1:
            if(CelFahr < 25)
            {
                LED.setRGB(0, 255, 0);
            }
            else if(CelFahr > 25 && CelFahr < 28)
            {
                LED.setRGB(255, 255, 0);
            }
            else if(CelFahr > 28)
            {
                LED.setRGB(255, 0, 0);
            }
            break;
    }
}

void Text()
{
    while(1)
    {
        lcd.DisplayStringAt(0, LINE(1), (uint8_t*)t, CENTER_MODE);
        wait(0.5);
    }
}
// Touchscreen functionality
void TTouch()
{   
    // Position of the touch area
    int MinX = 200;
    int MinY = 200;
    int MaxX = 280;
    int MaxY = 250;
    
    uint16_t x, y;
    
    uint8_t status;
    status = ts.Init(lcd.GetXSize(), lcd.GetYSize());
    TS_StateTypeDef TS_State;                         // Initialize object
    lcd.SetTextColor(LCD_COLOR_RED);
    lcd.DrawRect(200, 200, 80, 50);                   // Visualize touch area
    char test[1];
    while(1)
    {
        ts.GetState(&TS_State);                       // Find current cursor/finger position
        if(TS_State.touchDetected)                    // Run if the screen is touched
        {
            for (int idx = 0; idx < TS_State.touchDetected; idx++) 
            {
                x = TS_State.touchX[idx];             // Find current x position of cursor/finger
                y = TS_State.touchY[idx];             // Find current y position of cursor/finger
                if(x > MinX && x < MaxX && y > MinY && y < MaxY) // Check if the cursor/finger is within the rectangle
                {
                    BlueLight = 1;
                    if(change == 0)
                    {
                        change = 1;
                        wait(0.5);
                    }
                    else if(change == 1)
                    {
                        change = 0;
                        wait(0.5);
                    }
                    sprintf((char*)test, "    e: %d    ", change);
                    lcd.DisplayStringAt(0, LINE(4), (uint8_t*)test, CENTER_MODE);
                }
                else
                {
                    BlueLight = 0;
                }
            }
        }
        else
        {
            BlueLight = 0;
        }
    }
}

int main()
{
    while(1) 
    {    
        lcd.SetBackColor(LCD_COLOR_WHITE);
        lcd.SetTextColor(LCD_COLOR_BLACK);
        if(change == 0)
        {
            TempMath(0);
        }
        else if(change == 1)
        {
            TempMath(1);
        }
        Cthread.start(TTouch);
        LCDThread.start(Text);
    }
}

